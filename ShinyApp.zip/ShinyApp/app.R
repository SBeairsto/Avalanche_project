library(shiny)
library(data.table)
library(plyr)
library(readr)
library(tidyverse)
library(lubridate)
library(naniar)
library(roll)
library(activityCounts)
library(zoo)
library(dplyr)

#############################################################################
####   CODE TO BE RUN OUTSIDE SERVER 
############################################################################


raw_SWE_data <- read.csv("https://raw.githubusercontent.com/SBeairsto/Avalanche_project/main/snow_data/Squam_SWE.csv",header = TRUE)
#We now drop the columns which correspond to data quality (we explore that for ourselves)
raw_SWE_data = subset(raw_SWE_data, select = -c(X.1,X.2,X.3,X.4) )

#Rename variables with descriptive names
names(raw_SWE_data)[1] <- "Date"
names(raw_SWE_data)[2] <- "SWE"

#convert data to appropriate format (imported as char)
raw_SWE_data <- transform(raw_SWE_data, SWE = as.numeric(SWE))
raw_SWE_data$Date <- as.POSIXct(raw_SWE_data$Date,format="%Y-%m-%d %H:%M:%S",tz="GMT")


raw_PC_data <- read.csv("https://raw.githubusercontent.com/SBeairsto/Avalanche_project/main/snow_data/Squam_PC.csv",header = TRUE)
#We now drop the columns which correspond to data quality (we explore that for ourselves)
raw_PC_data = subset(raw_PC_data, select = -c(X.1,X.2,X.3,X.4) )

#Rename variables with descriptive names
names(raw_PC_data)[1] <- "Date"
names(raw_PC_data)[2] <- "PC"

#convert data to appropriate format (imported as char)
raw_PC_data <- transform(raw_PC_data, PC = as.numeric(PC))
raw_PC_data$Date <- as.POSIXct(raw_PC_data$Date,format="%Y-%m-%d %H:%M:%S",tz="GMT")

raw_SD_data <- read.csv("https://raw.githubusercontent.com/SBeairsto/Avalanche_project/main/snow_data/Squam_SD.csv",header = TRUE)
#We now drop the columns which correspond to data quality (we explore that for ourselves)
raw_SD_data = subset(raw_SD_data, select = -c(X.1,X.2,X.3,X.4) )

#Rename variables with descriptive names
names(raw_SD_data)[1] <- "Date"
names(raw_SD_data)[2] <- "SD"

#convert data to appropriate format (imported as char)
raw_SD_data <- transform(raw_SD_data, SD = as.numeric(SD))
raw_SD_data$Date <- as.POSIXct(raw_SD_data$Date,format="%Y-%m-%d %H:%M:%S",tz="GMT")


raw_data <- left_join(raw_SWE_data,raw_PC_data)
raw_data <- left_join(raw_data,raw_SD_data)

wind_data <- read.csv(url("https://raw.githubusercontent.com/SBeairsto/Avalanche_project/main/Data/Callaghan_wind_all.csv"))

#Rename variables with descriptive names
names(raw_SWE_data)[1] <- "Date"
names(raw_SWE_data)[2] <- "SWE"

#convert data to appropriate format (imported as char)
raw_SWE_data <- transform(raw_SWE_data, SWE = as.numeric(SWE))
raw_SWE_data$Date <- as.POSIXct(raw_SWE_data$Date,format="%Y-%m-%d %H:%M:%S",tz="GMT")

############################################################################
###   UI
############################################################################

ui <- 
  
  navbarPage("Sea-to-Sky Avalanches",
             theme = shinytheme("flatly"),
             tabPanel('About',
                      p('Our project looks at building an avalanche danger 
                        predictor for the Sea-to-Sky region using mahine 
                        learning methods. Here probs include stuff on what
                        an avalanche danger rating means, the 1-5 scale the
                        various elevation zones, how we are doing only alpine,
                        some form of disclamer saying this is just a little 
                        project, dont use it for safety reasons. Also something
                        about high dimensionality of data and we dont have
                        a whole whack of data points. Also a little blurb on
                        machine learning.')),
  navbarMenu("Available Data",
  tabPanel("Precipitation",
           
           
           
           h1('Precipitation'),
           p('Precipitation plays an essential role in avalanche danger, with 
             snowfall playing a particularly important role—blah blah blah basic
             theory of snowfall and avalanche danger. Available measurements of 
             precipitation in the Sea-to-Sky corridor include cumulative 
             precipitation (PC), snow water equivalent (SWE), and snow depth
             (SD). SWE and PC are used to measure liquid precipitation, which 
             does not have a one-to-one ratio with snowfall. However, it is 
             relatively close, with snow density being 5%-20% that of water, 
             depending on temperature, making liquid precipitation a relatively
             good measurement of snowfall.'),
           
           h2('Snow Water Equivalent'),
           includeMarkdown("SWE.md"),
           
           h2('Cumulative Precipitation'),
           includeMarkdown("PC.md"),
           
           h2('Snow Depth'),
           includeMarkdown("SD.md"),
           
           
           p('Below we have a plot of the raw precipiation data from the',
           a(href = 'https://aqrt.nrs.gov.bc.ca/Data/DataSet/Summary/Location/3A25P/DataSet/PC/Telemetry/Interval/AllData',
             'Squamish River Upper station'), 'provided by the BC government.'),
           
  dateRangeInput("daterange", "Date range:",
                 start  = "2011-11-01",
                 end    = "2012-05-01",
                 min    = "2011-01-01",
                 max    = "2019-09-01",
                 format = "mm/dd/yy",
                 separator = " - "),
  
  checkboxInput("SWE_box", "SWE" , value = TRUE),
  checkboxInput("PC_box", "PC" , value = FALSE),
  checkboxInput("SD_box", "SD" , value = FALSE),
  
 # textOutput("text"),
  
  
  #DTOutput("table"),
  plotOutput("graph_SWE"),
  
 h2('Conclusions'),
 p('Now, there is a lot of cleaning that can be done on all three data sets to
   vastly improve them, however, due to reasons explained above, SD is not an
   excellent measurement for snowfall, and the PC data is significantly less 
   reliable than the SWE data. For these reasons, we use SWE as our
   measurement of daily precipitation moving forward.'),
 
 br(),
 br(),
 
 p('*Thanks Tony at the BC Ministry of Environment and Climate Change Strategy 
   for the help understanding the precipitation measurements,')
 
    ),
 
 tabPanel('Wind', 
 p("Wind plays a vital role in avalanche danger, particularly in its role in
 forming wind slabs. Blah, blah, blah, the theory of wind and wind slabs. 
 Unfortunately, high elevation wind data in the Sea-to-Sky region is hard to 
 come by. There is now a station on Mt. Cayley (1588m); however, the station's
 wind data only goes as far back as 2015. There must be historical wind data 
 from Whistler-Blackcomb, but it does not appear to be publicly available. 
 The highest elevation station with data dating back to 2011 is the Callaghan
 Valley station (884m)."),
 
 p("The Callaghan Valley data is available from", 
 a(href = 'https://drive.google.com/drive/folders/1WJCDEU34c60IfOnG4rv5EPZ4IhhW9vZH',
             'Environment Canada'),
 "and contains hourly wind speed, which is measured in km/h, as well as wind
 direction in tens of degrees (0,10,20 degrees etc.). The current hurdle with
 wind direction is it holds an NA value when wind speed is zero 
 (which occurs quite frequently). A possible solution would be to bin wind 
 directions into classes, S, SE, E, etc. and include an NA class for when 
 wind speed is zero. We would appreciate any input here! For the moment, 
 however, our model takes into account only the wind speed."),
 
 dateRangeInput("wind_daterange", "Date range:",
                start  = "2011-11-01",
                end    = "2012-05-01",
                min    = "2011-01-01",
                max    = "2019-09-01",
                format = "mm/dd/yy",
                separator = " - "),
 
 checkboxInput("Raw_wind", "Raw wind speed data" , value = TRUE),
 checkboxInput("mean_wind", "Daily mean wind" , value = FALSE),
 checkboxInput("max_wind", "Daily max wind" , value = FALSE),
 
 plotOutput("graph_wind")
 
 ),
 
 tabPanel('Temperature')
  ),
 tabPanel('Previous Work',),
 tabPanel('Our Data Set',),
 tabPanel('Exploring the Data Set',),
 
 navbarMenu("Standard Machine Learning Methods",
 tabPanel('Support Vector Machine',),
 tabPanel('K-Nearest-Neighbours',),
 tabPanel('Random Forest',)
 ),
 
 tabPanel('Ordinal Random Forest')
)





############################################################################
###   SERVER
############################################################################

server <- function(input, output){
  
  
  #
  data_table <- reactive({ raw_data[raw_data$Date >= as.POSIXct(input$daterange[1])
                                    & raw_data$Date <= as.POSIXct(input$daterange[2]),]})
  
  output$graph_SWE <- renderPlot({
    if(input$SWE_box & input$PC_box & input$SD_box){
      ggplot(data_table(), aes(Date)) + 
        geom_line(aes(y = PC, colour = "PC")) +
        geom_line(aes(y = SWE, colour = "SWE"))+
        geom_line(aes(y = SD, colour = "SD"))} 
    else if(input$SWE_box & input$PC_box & !input$SD_box){
      ggplot(data_table(), aes(Date)) + 
        geom_line(aes(y = PC, colour = "PC")) +
        geom_line(aes(y = SWE, colour = "SWE"))}
        #geom_line(aes(y = SD, colour = "SD")) 
    else if(input$SWE_box & !input$PC_box & !input$SD_box){
        ggplot(data_table(), aes(Date)) + 
          #geom_line(aes(y = PC, colour = "PC")) +
          geom_line(aes(y = SWE, colour = "SWE"))}
    else if(input$SWE_box & !input$PC_box & input$SD_box){
      ggplot(data_table(), aes(Date)) + 
        #geom_line(aes(y = PC, colour = "PC")) +
        geom_line(aes(y = SWE, colour = "SWE"))+
        geom_line(aes(y = SD, colour = "SD"))}  
    else if(!input$SWE_box & input$PC_box & input$SD_box){
      ggplot(data_table(), aes(Date)) + 
        geom_line(aes(y = PC, colour = "PC")) +
        #geom_line(aes(y = SWE, colour = "SWE"))}+
        geom_line(aes(y = SD, colour = "SD")) }
    else if(!input$SWE_box & input$PC_box & !input$SD_box){
        ggplot(data_table(), aes(Date)) + 
          geom_line(aes(y = PC, colour = "PC")) }
          #geom_line(aes(y = SWE, colour = "SWE"))}+
          #geom_line(aes(y = SD, colour = "SD")) }
    else if(!input$SWE_box & !input$PC_box & input$SD_box){
        ggplot(data_table(), aes(Date)) + 
          #geom_line(aes(y = PC, colour = "PC")) }
          #geom_line(aes(y = SWE, colour = "SWE"))}+
        geom_line(aes(y = SD, colour = "SD")) }
    else{ggplot(data_table(), aes(Date))}
  })
  
  #
  wind_data_table <- reactive({ wind_data[wind_data$Date >= as.POSIXct(input$wind_daterange[1])
                                    & wind_data$Date <= as.POSIXct(input$wind_daterange[2]),]})
  
  output$graph_wind <- renderPlot({
    if(input$mean_wind & input$raw_wind & input$max_wind){
      ggplot(wind_data_table(), aes(Date)) + 
        geom_line(aes(y = Wind.Spd..km.h, colour = "PC")) +
        geom_line(aes(y = Daily_mean_wind, colour = "SWE"))+
        geom_line(aes(y = Daily_max_wind, colour = "SD"))} 
    else if(input$mean_wind & input$raw_wind & !input$max_wind){
      ggplot(wind_data_table(), aes(Date)) + 
        geom_line(aes(y = Wind.Spd..km.h, colour = "PC")) +
        geom_line(aes(y = Daily_mean_wind, colour = "SWE"))}
    #geom_line(aes(y = SD, colour = "SD")) 
    else if(input$mean_wind & !input$raw_wind & !input$max_wind){
      ggplot(wind_data_table(), aes(Date)) + 
        #geom_line(aes(y = PC, colour = "PC")) +
        geom_line(aes(y = Daily_mean_wind, colour = "SWE"))}
    else if(input$mean_wind & !input$raw_wind & input$max_wind){
      ggplot(wind_data_table(), aes(Date)) + 
        #geom_line(aes(y = PC, colour = "PC")) +
        geom_line(aes(y = Daily_mean_wind, colour = "SWE"))+
        geom_line(aes(y = Daily_max_wind, colour = "SD"))}  
    else if(!input$mean_wind & input$raw_wind & input$max_wind){
      ggplot(wind_data_table(), aes(Date)) + 
        geom_line(aes(y = Wind.Spd..km.h, colour = "PC")) +
        #geom_line(aes(y = SWE, colour = "SWE"))}+
        geom_line(aes(y = Daily_max_wind, colour = "SD")) }
    else if(!input$mean_wind & input$raw_wind & !input$max_wind){
      ggplot(wind_data_table(), aes(Date)) + 
        geom_line(aes(y = Wind.Spd..km.h, colour = "PC")) }
    #geom_line(aes(y = SWE, colour = "SWE"))}+
    #geom_line(aes(y = SD, colour = "SD")) }
    else if(!input$mean_wind & !input$raw_wind & input$max_wind){
      ggplot(wind_data_table(), aes(Date)) + 
        #geom_line(aes(y = PC, colour = "PC")) }
        #geom_line(aes(y = SWE, colour = "SWE"))}+
        geom_line(aes(y = Daily_max_wind, colour = "SD")) }
    else{ggplot(data_table(), aes(Date))}
  })

  
}

############################################################################

shinyApp(ui = ui, server = server)